﻿========================================================================
VORA - FICHIERS D'ENVIRONNEMENT CLES HACKATHON NUXCINE (TEAM-VANGUARD)
========================================================================

Ce dossier contient les fichiers de configuration et cles d'API operationnelles
pour executer la plateforme VORA sans configuration manuelle :

1. backend.env :
   A copier / renommer en 'backend/.env' :
   - Database Neon PostgreSQL Cloud
   - Cles Clerk Auth (secret & publishable)
   - Cles Google OAuth
   - Cles CamerPay Mobile Money (MTN & Orange)
   - Identifiants administrateur par defaut (admin@vora.cm / VoraAdmin2025!)

2. mobile.env :
   A copier / renommer en 'mobile/.env' :
   - Cles Clerk Auth
   - Cles Google OAuth
   - Cles Google Gemini AI (IA geocodage reperes informels & IA faciale)
   - Cles Geoapify (Maps, Places, Directions)
   - Cles CamerPay Mobile Money

Pour appliquer automatiquement ces fichiers a la racine du projet :
- Windows (PowerShell) :
    Copy-Item env-configs/backend.env backend/.env
    Copy-Item env-configs/mobile.env mobile/.env

- Linux / macOS (Bash) :
    cp env-configs/backend.env backend/.env
    cp env-configs/mobile.env mobile/.env
========================================================================
